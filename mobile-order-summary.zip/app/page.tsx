"use client"

import { useState } from "react"
import dynamic from "next/dynamic"
import "leaflet/dist/leaflet.css"
import { Icon } from "leaflet"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Truck, MapPin, Clock, Calendar } from "lucide-react"
import LogSheet from "@/components/log-sheet"
import TripSummary from "@/components/trip-summary"
import LocationSearch from "@/components/location-search"
import { calculateRoute, generateLogSheets } from "@/lib/trip-calculator"

// Dynamically import the map component with no SSR
const MapWithNoSSR = dynamic(() => import("@/components/map-component"), {
  ssr: false,
  loading: () => <div className="h-[500px] w-full bg-gray-100 flex items-center justify-center">Loading Map...</div>,
})

// Fix for Leaflet icon in Next.js
const customIcon = new Icon({
  iconUrl: "/placeholder.svg?height=25&width=25",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
})

export default function Home() {
  const [currentLocation, setCurrentLocation] = useState("")
  const [pickupLocation, setPickupLocation] = useState("")
  const [dropoffLocation, setDropoffLocation] = useState("")
  const [currentCycleHours, setCurrentCycleHours] = useState("0")
  const [route, setRoute] = useState(null)
  const [logSheets, setLogSheets] = useState([])
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("input")
  const router = useRouter()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      // In a real app, this would call the Django backend
      // For demo purposes, we'll use our frontend simulation
      const routeData = await calculateRoute(
        currentLocation,
        pickupLocation,
        dropoffLocation,
        Number.parseFloat(currentCycleHours),
      )

      setRoute(routeData)

      const logs = generateLogSheets(routeData)
      setLogSheets(logs)

      setActiveTab("map")
    } catch (error) {
      console.error("Error calculating route:", error)
      // Handle error state
    } finally {
      setLoading(false)
    }
  }

  const handleReset = () => {
    setCurrentLocation("")
    setPickupLocation("")
    setDropoffLocation("")
    setCurrentCycleHours("0")
    setRoute(null)
    setLogSheets([])
    setActiveTab("input")
  }

  return (
    <main className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <div className="flex items-center space-x-3">
            <Truck className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold text-gray-900">ELD Trip Planner</h1>
          </div>
          <p className="text-gray-600 mt-2">Plan your trips with automatic ELD compliance and log generation</p>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-8">
            <TabsTrigger value="input">Trip Details</TabsTrigger>
            <TabsTrigger value="map" disabled={!route}>
              Route Map
            </TabsTrigger>
            <TabsTrigger value="logs" disabled={!route}>
              ELD Logs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="input">
            <Card>
              <CardHeader>
                <CardTitle>Enter Trip Details</CardTitle>
                <CardDescription>
                  Provide your current location, pickup and dropoff points, and current cycle hours
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="currentLocation" className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" /> Current Location
                      </Label>
                      <LocationSearch
                        id="currentLocation"
                        value={currentLocation}
                        onChange={setCurrentLocation}
                        placeholder="Enter your current location"
                      />
                    </div>

                    <div>
                      <Label htmlFor="pickupLocation" className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" /> Pickup Location
                      </Label>
                      <LocationSearch
                        id="pickupLocation"
                        value={pickupLocation}
                        onChange={setPickupLocation}
                        placeholder="Enter pickup location"
                      />
                    </div>

                    <div>
                      <Label htmlFor="dropoffLocation" className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" /> Dropoff Location
                      </Label>
                      <LocationSearch
                        id="dropoffLocation"
                        value={dropoffLocation}
                        onChange={setDropoffLocation}
                        placeholder="Enter dropoff location"
                      />
                    </div>

                    <div>
                      <Label htmlFor="currentCycleHours" className="flex items-center gap-2">
                        <Clock className="h-4 w-4" /> Current Cycle Hours Used
                      </Label>
                      <Input
                        id="currentCycleHours"
                        type="number"
                        min="0"
                        max="70"
                        step="0.5"
                        value={currentCycleHours}
                        onChange={(e) => setCurrentCycleHours(e.target.value)}
                        placeholder="Enter hours used in current cycle (0-70)"
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? "Calculating..." : "Calculate Route & Generate Logs"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="map">
            {route && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Route Map</CardTitle>
                    <CardDescription>Your route with required stops for rest, fuel, and ELD compliance</CardDescription>
                  </CardHeader>
                  <CardContent className="p-0">{route && <MapWithNoSSR waypoints={route.waypoints} />}</CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Trip Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <TripSummary route={route} />
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={handleReset}>
                      New Trip
                    </Button>
                    <Button onClick={() => setActiveTab("logs")}>View ELD Logs</Button>
                  </CardFooter>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="logs">
            {logSheets.length > 0 && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Electronic Logging Device (ELD) Records</CardTitle>
                    <CardDescription>Generated log sheets for your trip based on HOS regulations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-8">
                      {logSheets.map((log, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                            <Calendar className="h-5 w-5" />
                            Day {index + 1}: {log.date}
                          </h3>
                          <LogSheet logData={log} />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" onClick={() => setActiveTab("map")}>
                      Back to Map
                    </Button>
                    <Button variant="outline" onClick={handleReset}>
                      New Trip
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}

