"use client"

import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet"
import "leaflet/dist/leaflet.css"
import { Icon } from "leaflet"

// Fix for Leaflet icon in Next.js
const customIcon = new Icon({
  iconUrl: "/placeholder.svg?height=25&width=25",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
})

interface MapComponentProps {
  waypoints: {
    type: string
    location: string
    coordinates: [number, number]
    duration?: number
  }[]
}

export default function MapComponent({ waypoints }: MapComponentProps) {
  if (!waypoints || waypoints.length === 0) {
    return <div className="h-[500px] w-full bg-gray-100 flex items-center justify-center">No route data available</div>
  }

  return (
    <div className="h-[500px] w-full">
      <MapContainer center={waypoints[0].coordinates} zoom={5} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {waypoints.map((waypoint, index) => (
          <Marker key={index} position={waypoint.coordinates} icon={customIcon}>
            <Popup>
              <div>
                <h3 className="font-bold">{waypoint.type}</h3>
                <p>{waypoint.location}</p>
                {waypoint.duration && <p>Duration: {waypoint.duration} hours</p>}
              </div>
            </Popup>
          </Marker>
        ))}

        <Polyline positions={waypoints.map((wp) => wp.coordinates)} color="blue" />
      </MapContainer>
    </div>
  )
}

