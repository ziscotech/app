"use client"

import { useState, useEffect } from "react"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Check, ChevronsUpDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

// Simulated location search API
const searchLocations = async (query: string) => {
  // In a real app, this would call a geocoding API
  if (!query || query.length < 3) return []

  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Mock data for demo
  const mockLocations = [
    { id: "1", name: `${query}, New York, NY` },
    { id: "2", name: `${query}, Los Angeles, CA` },
    { id: "3", name: `${query}, Chicago, IL` },
    { id: "4", name: `${query}, Houston, TX` },
    { id: "5", name: `${query}, Phoenix, AZ` },
  ]

  return mockLocations
}

interface LocationSearchProps {
  id: string
  value: string
  onChange: (value: string) => void
  placeholder?: string
}

export default function LocationSearch({ id, value, onChange, placeholder }: LocationSearchProps) {
  const [open, setOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [locations, setLocations] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const fetchLocations = async () => {
      if (searchQuery.length < 3) {
        setLocations([])
        return
      }

      setLoading(true)
      try {
        const results = await searchLocations(searchQuery)
        setLocations(results)
      } catch (error) {
        console.error("Error searching locations:", error)
      } finally {
        setLoading(false)
      }
    }

    const timeoutId = setTimeout(fetchLocations, 300)
    return () => clearTimeout(timeoutId)
  }, [searchQuery])

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" role="combobox" aria-expanded={open} className="w-full justify-between mt-1">
          {value || placeholder || "Search locations..."}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-full p-0">
        <Command>
          <CommandInput placeholder="Search location..." value={searchQuery} onValueChange={setSearchQuery} />
          <CommandList>
            {loading && <CommandEmpty>Searching...</CommandEmpty>}
            {!loading && searchQuery.length < 3 && <CommandEmpty>Enter at least 3 characters</CommandEmpty>}
            {!loading && searchQuery.length >= 3 && locations.length === 0 && (
              <CommandEmpty>No locations found</CommandEmpty>
            )}
            <CommandGroup>
              {locations.map((location) => (
                <CommandItem
                  key={location.id}
                  value={location.name}
                  onSelect={(currentValue) => {
                    onChange(currentValue)
                    setOpen(false)
                  }}
                >
                  <Check className={cn("mr-2 h-4 w-4", value === location.name ? "opacity-100" : "opacity-0")} />
                  {location.name}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}

