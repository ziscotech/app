import { Card, CardContent } from "@/components/ui/card"
import { Clock, MapPin, Fuel, Calendar, AlertTriangle } from "lucide-react"

interface TripSummaryProps {
  route: {
    totalDistance: number
    totalDrivingTime: number
    totalTripTime: number
    waypoints: {
      type: string
      location: string
      coordinates: [number, number]
      duration?: number
      arrivalTime?: string
      departureTime?: string
    }[]
    startDate: string
    endDate: string
    fuelStops: number
    restStops: number
  }
}

export default function TripSummary({ route }: TripSummaryProps) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-gray-500">Total Distance</p>
                <p className="font-semibold">{route.totalDistance.toLocaleString()} miles</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-gray-500">Driving Time</p>
                <p className="font-semibold">{route.totalDrivingTime} hours</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-gray-500">Trip Duration</p>
              <p className="font-semibold">
                {route.startDate} to {route.endDate}
              </p>
              <p className="text-sm text-gray-500">Total: {route.totalTripTime} hours</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Fuel className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-gray-500">Fuel Stops</p>
                <p className="font-semibold">{route.fuelStops}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-gray-500">Required Rest Stops</p>
                <p className="font-semibold">{route.restStops}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-4">
        <h3 className="font-semibold mb-2">Key Locations</h3>
        <div className="space-y-2">
          {route.waypoints
            .filter((wp) => ["start", "pickup", "dropoff", "end"].includes(wp.type))
            .map((waypoint, index) => (
              <div key={index} className="flex items-start gap-2 p-2 border-b">
                <MapPin className="h-4 w-4 text-primary mt-1" />
                <div>
                  <p className="font-medium capitalize">{waypoint.type}</p>
                  <p className="text-sm text-gray-600">{waypoint.location}</p>
                  {waypoint.arrivalTime && <p className="text-xs text-gray-500">Arrival: {waypoint.arrivalTime}</p>}
                  {waypoint.departureTime && (
                    <p className="text-xs text-gray-500">Departure: {waypoint.departureTime}</p>
                  )}
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  )
}

